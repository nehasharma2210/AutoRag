# Complete System Explanation

## 📋 Overview

This is a **HYBRID OFFLINE/ONLINE** Self-Healing RAG (Retrieval Augmented Generation) system. It works **primarily offline** with your local knowledge base, but **automatically goes online** when it detects that its answers have low confidence.

---

## 🔍 What is RAG?

**RAG (Retrieval Augmented Generation)** combines:
1. **Retrieval**: Search a knowledge base for relevant information
2. **Augmentation**: Use that information to enhance answers
3. **Generation**: Produce better, more accurate answers

---

## 🏗️ System Architecture

### **OFFLINE Components** (Runs Locally)
- ✅ **Base Knowledge Base**: Wikitext dataset (stored locally)
- ✅ **Embedding Model**: Sentence transformers (downloaded once, runs locally)
- ✅ **FAISS Vector Database**: Index of all text chunks (created locally)
- ✅ **Answer Generation**: All processing happens on your machine

### **ONLINE Components** (Only When Needed)
- 🌐 **Wikipedia API**: Fetches information when base knowledge is insufficient
- 🌐 **Web Search**: Uses DuckDuckGo to find additional sources
- 🌐 **Web Scraping**: Extracts content from websites

---

## 📁 File Breakdown

### 1. **`self_healing_rag.py`** - Main Application ⭐
**Purpose**: The core FastAPI application with all the RAG logic

**What it does**:
- **Initialization** (`startup_event`):
  - Downloads sentence transformer model (if not cached) - ~80MB
  - Loads Wikitext dataset (if not cached) - ~500MB
  - Creates embeddings (vector representations) of all text chunks
  - Builds FAISS index for fast similarity search
  - All stored in memory/disk locally

- **Query Processing** (`autorag_with_diff`):
  ```
  1. User asks a question
  2. Convert question to embedding (vector)
  3. Search base knowledge base (OFFLINE - FAISS index)
  4. Calculate trust score (how relevant the results are)
  5. If score < threshold (0.5):
     → GO ONLINE:
        - Search Wikipedia API
        - Search web via DuckDuckGo
        - Extract and clean content
        - Create new embeddings
        - Build temporary index
     → Compare results
     → Use best answer
  6. Return answer + metadata
  ```

- **Self-Healing Function** (`self_heal`):
  - Tries Wikipedia API first (most reliable)
  - Falls back to web search if needed
  - Extracts and cleans content from web pages
  - Returns chunks ready to be indexed

- **API Endpoints**:
  - `POST /query`: Main query endpoint
  - `POST /query/demo`: Formatted demo endpoint
  - `GET /health`: System health check
  - `GET /`: API information

---

### 2. **`run_rag.py`** - Demo Script
**Purpose**: Simple command-line script to test the system without starting the API server

**What it does**:
- Initializes the RAG system
- Runs demo queries automatically
- Prints formatted results to console
- Shows before/after comparison

**Use case**: Quick testing without web interface

---

### 3. **`requirements.txt`** - Dependencies
**Purpose**: Lists all Python packages needed

**Key Dependencies**:
- `fastapi`, `uvicorn`: Web server framework
- `sentence-transformers`: Creates embeddings (vector representations)
- `faiss-cpu`: Fast similarity search engine
- `datasets`: Loads Wikitext dataset
- `torch`, `transformers`: Deep learning frameworks
- `beautifulsoup4`: Web scraping/HTML parsing
- `duckduckgo-search`: Web search functionality
- `requests`: HTTP requests to APIs/websites

---

### 4. **`README.md`** - Documentation
**Purpose**: User guide and API documentation

**Contains**:
- Installation instructions
- Usage examples
- API endpoint documentation
- Configuration options

---

### 5. **`install.bat`, `install.ps1`, `install_step_by_step.bat`** - Installation Scripts
**Purpose**: Helper scripts to install dependencies on Windows

- `install.bat`: Simple batch file for Windows
- `install.ps1`: PowerShell version
- `install_step_by_step.bat`: Detailed step-by-step installation

---

### 6. **`Untitled3.ipynb`** - Original Jupyter Notebook
**Purpose**: The original notebook version (before conversion to FastAPI)

**Status**: Reference only - you're now using the Python files instead

---

## 🔄 How It Works (Step by Step)

### **Initial Setup (First Run Only - Takes ~5-10 minutes)**
```
1. Download sentence transformer model (~80MB)
   Location: ~/.cache/huggingface/ (usually)
   
2. Download Wikitext dataset (~500MB)
   Location: ~/.cache/huggingface/datasets/ (usually)
   
3. Process dataset:
   - Split into chunks (500 chars each, 50 char overlap)
   - Create embeddings (vector representations)
   - Build FAISS index
   - Store in memory
```

### **Normal Query Flow (OFFLINE)**
```
User Query: "What is quantum computing?"

1. Convert query to embedding vector
   └─> Uses sentence transformer model (OFFLINE)

2. Search base knowledge base
   └─> FAISS similarity search (OFFLINE)
   └─> Returns top 5 most relevant chunks

3. Calculate trust score
   └─> Average similarity score (e.g., 0.732 = good, 0.19 = poor)

4. If score >= 0.5:
   └─> Return answer from base knowledge (OFFLINE - FAST)
   
5. If score < 0.5:
   └─> TRIGGER SELF-HEALING (GO ONLINE)
```

### **Self-Healing Flow (ONLINE - Only When Needed)**
```
When trust score < 0.5:

1. Wikipedia Search (ONLINE):
   ├─ Try direct page lookup
   ├─ If fails, use Wikipedia search API
   └─ Extract summary text (~817 chars)

2. Web Search (ONLINE - if Wikipedia insufficient):
   ├─ Search DuckDuckGo for relevant pages
   ├─ Fetch web pages
   ├─ Extract main content (4 strategies):
   │   ├─ Strategy 1: Look for <main>/<article> tags
   │   ├─ Strategy 2: Search content divs
   │   ├─ Strategy 3: Extract paragraphs
   │   └─ Strategy 4: Fallback to body text
   └─ Clean and filter content

3. Create embeddings for new content (OFFLINE):
   └─ Uses same sentence transformer model

4. Build temporary FAISS index (OFFLINE)
   └─ For fast search in new content

5. Search new content (OFFLINE)
   └─ Find most relevant chunks

6. Compare scores:
   ├─ If healed score > base score * 1.15:
   │   └─ Use healed results ✅
   ├─ If base score < 0.3 (very poor):
   │   └─ Use healed results if better ✅
   └─ Otherwise:
       └─ Combine both or keep base

7. Generate final answer
   └─ Clean, format, remove duplicates
```

---

## 🌐 Is It Offline or Online?

### **PRIMARILY OFFLINE** ✅
- Base knowledge base is stored locally
- Embedding model runs on your machine
- FAISS index is in memory
- Most queries never go online

### **ONLINE WHEN NEEDED** 🌐
- Only goes online if:
  1. Trust score < threshold (0.5)
  2. AND `use_healing=True`
- Makes HTTP requests to:
  - Wikipedia API
  - DuckDuckGo search
  - Web pages (for scraping)

### **Network Requirements**
- **First run**: Needs internet to download model + dataset
- **Subsequent runs**: 
  - Works completely offline for queries with good base matches
  - Needs internet only for self-healing (low confidence queries)

---

## 💾 Data Storage

### **Local Storage Locations**:
1. **Model Cache**: `~/.cache/huggingface/hub/`
   - Sentence transformer model
   - Downloaded once, reused forever

2. **Dataset Cache**: `~/.cache/huggingface/datasets/`
   - Wikitext dataset
   - Downloaded once

3. **Runtime Memory**:
   - FAISS index (loaded at startup)
   - Embeddings (in memory)
   - Text chunks (in memory)

### **No Persistent Database**:
- Everything is loaded fresh at startup
- Index rebuilt each time (but fast with FAISS)

---

## ⚡ Performance

### **OFFLINE Queries** (No internet needed):
- Speed: ~100-500ms per query
- Uses only local resources

### **ONLINE Queries** (Self-healing triggered):
- Speed: ~5-15 seconds per query
- Includes:
  - Wikipedia API call: ~1-2s
  - Web search: ~3-5s
  - Web scraping: ~2-5s per page
  - Processing: ~1-2s

---

## 🎯 Key Features

### 1. **Intelligent Self-Healing**
- Automatically detects poor answers
- Searches for better information
- Only triggers when needed

### 2. **Multi-Strategy Web Scraping**
- 4 different extraction strategies
- Handles various website structures
- Cleans noise and ads

### 3. **Hybrid Retrieval**
- Combines base knowledge + external sources
- Chooses best results intelligently
- Falls back gracefully

### 4. **FastAPI Web API**
- RESTful API interface
- Automatic documentation (Swagger UI)
- Easy integration with other apps

---

## 🔧 Configuration Options

You can adjust in `QueryRequest`:
- `threshold`: When to trigger healing (default: 0.5)
- `max_results`: How many chunks to return (default: 5)
- `use_healing`: Enable/disable self-healing (default: true)

---

## 📊 Example Flow Visualization

```
User: "What is quantum computing?"
        │
        ▼
┌─────────────────────────┐
│ Convert to Embedding    │  (OFFLINE)
│ (Sentence Transformer)  │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ Search Base Knowledge   │  (OFFLINE)
│ (FAISS Index)           │
└───────────┬─────────────┘
            │
            ▼
    Trust Score: 0.19
    (Low confidence)
            │
            ▼
    ┌───────┴───────┐
    │ Trigger       │
    │ Self-Healing? │
    └───┬───────┬───┘
        │       │
    YES ▼       ▼ NO
        │       │
        │       └─────> Return Base Answer
        │
        ▼
┌─────────────────────────┐
│ Search Wikipedia API    │  (ONLINE)
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ Search Web (DuckDuckGo) │  (ONLINE)
│ Extract Content         │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ Create Embeddings       │  (OFFLINE)
│ Build Index             │
└───────────┬─────────────┘
            │
            ▼
┌─────────────────────────┐
│ Compare Scores          │
│ Base: 0.19              │
│ Healed: 0.732           │
└───────────┬─────────────┘
            │
            ▼
    Use Healed Results ✅
            │
            ▼
┌─────────────────────────┐
│ Generate Final Answer   │
│ "A quantum computer..." │
└─────────────────────────┘
```

---

## 🚀 Usage Modes

### Mode 1: FastAPI Server (Web API)
```bash
python self_healing_rag.py
```
- Access at: http://localhost:8000/docs
- Interactive API documentation
- Can be called from any HTTP client
- Good for integration with other apps

### Mode 2: Command Line Demo
```bash
python run_rag.py
```
- Runs predefined demo queries
- Shows formatted output in terminal
- Good for testing/development

---

## 🔒 Privacy & Security

### **Privacy**:
- Your queries are processed locally
- Only goes online for self-healing (when needed)
- No query data sent to external servers (except Wikipedia/web search)
- DuckDuckGo searches are anonymous

### **Security**:
- No authentication required (add your own if needed)
- Runs on localhost by default
- Be careful exposing to internet without security

---

## 📝 Summary

**This is a HYBRID system:**
- ✅ **Works offline** for most queries (using local Wikitext dataset)
- 🌐 **Goes online automatically** when confidence is low
- 🎯 **Self-healing** improves answers by fetching current information
- ⚡ **Fast** for offline queries, slower for online healing
- 🔧 **Flexible** - can disable online features entirely

**Best Use Cases:**
- General knowledge questions
- Technical explanations
- Recent topics (self-healing provides current info)
- Applications needing reliable Q&A

**Limitations:**
- First run requires internet (model download)
- Online healing requires internet
- Web scraping may fail on some sites
- Base dataset is from Wikitext (may be outdated)

